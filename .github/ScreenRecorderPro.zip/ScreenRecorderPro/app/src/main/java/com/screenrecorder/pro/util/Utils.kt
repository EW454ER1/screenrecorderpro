package com.screenrecorder.pro.util

import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object Formatters {
    fun duration(ms: Long): String {
        val total = max(0L, ms) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", bytes / 1073741824.0)
    }
}

object VideoSizing {
    /** أبعاد زوجية بنفس النسبة؛ الضلع الأقصر = targetShort (دون تكبير). */
    fun computeSize(realW: Int, realH: Int, targetShort: Int): Pair<Int, Int> {
        val short = min(realW, realH)
        val long = max(realW, realH)
        val scale = if (short <= targetShort) 1.0 else targetShort.toDouble() / short
        val s = even(short * scale)
        val l = even(long * scale)
        return if (realW <= realH) s to l else l to s
    }

    private fun even(v: Double): Int = max(2, (v.roundToInt() / 2) * 2)
}
