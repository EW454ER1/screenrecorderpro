package com.screenrecorder.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.screenrecorder.pro.data.RecorderState
import com.screenrecorder.pro.data.RecordingItem
import com.screenrecorder.pro.data.RecordingSettings
import com.screenrecorder.pro.data.RecordingsRepository
import com.screenrecorder.pro.data.SettingsStore
import com.screenrecorder.pro.data.Status
import com.screenrecorder.pro.recorder.RecorderService
import com.screenrecorder.pro.ui.AppTheme
import com.screenrecorder.pro.ui.MainActions
import com.screenrecorder.pro.ui.MainScreen
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var store: SettingsStore
    private var settings by mutableStateOf(RecordingSettings())
    private var recordings by mutableStateOf<List<RecordingItem>>(emptyList())

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        requestProjection()
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java)
                .setAction(RecorderService.ACTION_START)
                .putExtra(RecorderService.EXTRA_CODE, r.resultCode)
                .putExtra(RecorderService.EXTRA_DATA, data)
            ContextCompat.startForegroundService(this, i)
        } else {
            RecorderState.update { it.copy(error = "لم تتم الموافقة على تسجيل الشاشة") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)
        settings = store.load()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                refresh()
                RecorderState.state.map { it.status }.distinctUntilChanged().collect { if (it == Status.IDLE) refresh() }
            }
        }

        setContent {
            AppTheme {
                val ui by RecorderState.state.collectAsStateWithLifecycle()
                MainScreen(
                    ui, settings, recordings,
                    MainActions(
                        onSettings = ::applySettings,
                        onStart = ::startFlow,
                        onPause = { sendAction(RecorderService.ACTION_PAUSE) },
                        onResume = { sendAction(RecorderService.ACTION_RESUME) },
                        onStop = { sendAction(RecorderService.ACTION_STOP) },
                        onShare = ::share,
                        onDelete = ::delete,
                        onDismissError = { RecorderState.update { it.copy(error = null) } },
                    ),
                )
            }
        }
    }

    private fun refresh() { recordings = RecordingsRepository.list(this) }

    private fun applySettings(s: RecordingSettings) {
        val enablingFloating = s.floating && !settings.floating
        settings = s
        store.save(s)
        if (enablingFloating && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    private fun startFlow() {
        val needed = buildList {
            if (settings.mic || settings.internalAudio) add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) requestProjection() else permLauncher.launch(needed.toTypedArray())
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun sendAction(action: String) {
        startService(Intent(this, RecorderService::class.java).setAction(action))
    }

    private fun share(item: RecordingItem) {
        val send = Intent(Intent.ACTION_SEND)
            .setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, item.uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, "مشاركة التسجيل"))
    }

    private fun delete(item: RecordingItem) {
        if (RecordingsRepository.delete(this, item.uri)) refresh()
        else Toast.makeText(this, "تعذّر الحذف؛ احذف الملف من تطبيق المعرض", Toast.LENGTH_LONG).show()
    }
}
