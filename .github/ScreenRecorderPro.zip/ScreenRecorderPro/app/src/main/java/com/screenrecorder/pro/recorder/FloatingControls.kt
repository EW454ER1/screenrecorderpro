package com.screenrecorder.pro.recorder

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.screenrecorder.pro.util.Formatters

/** زر عائم صغير قابل للسحب: مؤقّت + إيقاف مؤقت/استئناف + إنهاء. */
class FloatingControls(
    private val context: Context,
    private val onTogglePause: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val wm = context.getSystemService(WindowManager::class.java)
    private var root: LinearLayout? = null
    private var timer: TextView? = null
    private var pauseBtn: TextView? = null
    private lateinit var params: WindowManager.LayoutParams

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (root != null || !Settings.canDrawOverlays(context)) return
        val bg = GradientDrawable().apply { setColor(0xE61B1F2A.toInt()); cornerRadius = dp(24).toFloat() }
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg
            setPadding(dp(12), dp(6), dp(8), dp(6))
        }
        val t = TextView(context).apply { text = "00:00"; setTextColor(Color.WHITE); textSize = 14f }
        val p = button("⏸") { onTogglePause() }
        val s = button("⏹") { onStop() }
        container.addView(t); container.addView(p); container.addView(s)
        timer = t; pauseBtn = p; root = container

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(120) }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(container, params) }
                }
            }
            true
        }
        runCatching { wm.addView(container, params) }
    }

    private fun button(label: String, action: () -> Unit) = TextView(context).apply {
        text = label; textSize = 20f; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(4), dp(4), dp(4))
        setOnClickListener { action() }
    }

    fun setTime(ms: Long) { timer?.text = Formatters.duration(ms) }
    fun setPaused(paused: Boolean) { pauseBtn?.text = if (paused) "▶" else "⏸" }

    fun hide() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
    }
}
