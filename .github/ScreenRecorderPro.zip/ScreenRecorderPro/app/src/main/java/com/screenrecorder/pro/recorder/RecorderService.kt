package com.screenrecorder.pro.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.StatFs
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.screenrecorder.pro.MainActivity
import com.screenrecorder.pro.R
import com.screenrecorder.pro.data.RecorderState
import com.screenrecorder.pro.data.SettingsStore
import com.screenrecorder.pro.data.Status
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class RecorderService : Service(), ScreenRecorderEngine.Listener {

    companion object {
        const val ACTION_START = "com.screenrecorder.pro.START"
        const val ACTION_PAUSE = "com.screenrecorder.pro.PAUSE"
        const val ACTION_RESUME = "com.screenrecorder.pro.RESUME"
        const val ACTION_STOP = "com.screenrecorder.pro.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "recording"
        private const val NOTIF_ID = 1
        private const val MIN_FREE_BYTES = 50L * 1024 * 1024
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var engine: ScreenRecorderEngine? = null
    private var overlay: FloatingControls? = null
    private var ticker: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL_ID, "التسجيل", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_PAUSE -> setPaused(true)
            ACTION_RESUME -> setPaused(false)
            ACTION_STOP -> stopRecording()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ start

    private fun handleStart(intent: Intent) {
        if (engine != null) return
        val settings = SettingsStore(this).load().effective()
        val audioGranted = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val useMic = settings.mic && audioGranted
        val useInternal = settings.internalAudio && audioGranted

        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (useMic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        startForeground(NOTIF_ID, buildNotification(false, 0), type)

        if ((settings.mic || settings.internalAudio) && !audioGranted) {
            toast("لم تُمنح صلاحية الصوت؛ سيتم التسجيل بدون صوت")
        }
        if (freeBytes() < 150L * 1024 * 1024) { failStart("مساحة التخزين غير كافية"); return }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) { failStart("لم تتم الموافقة على التسجيل"); return }

        try {
            val projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            val e = ScreenRecorderEngine(
                this, projection, settings.copy(mic = useMic, internalAudio = useInternal), this,
            )
            e.start()
            engine = e
        } catch (t: OutOfMemoryError) {
            failStart("نفدت الذاكرة؛ جرّب الوضع الاقتصادي أو دقة أقل"); return
        } catch (t: Exception) {
            failStart("تعذّر بدء التسجيل: ${t.message}"); return
        }

        RecorderState.update { it.copy(status = Status.RECORDING, elapsedMs = 0, sizeBytes = 0, error = null) }
        if (settings.floating) {
            overlay = FloatingControls(this, { togglePause() }, { stopRecording() }).also { it.show() }
        }
        ticker = scope.launch {
            while (isActive) {
                val e = engine ?: break
                val el = e.elapsedMs()
                RecorderState.update { it.copy(elapsedMs = el, sizeBytes = e.bytesWritten()) }
                overlay?.setTime(el)
                if (freeBytes() < MIN_FREE_BYTES) {
                    RecorderState.update { it.copy(error = "مساحة التخزين منخفضة؛ تم إيقاف التسجيل وحفظ الملف") }
                    stopRecording(); break
                }
                delay(500)
            }
        }
    }

    private fun failStart(message: String) {
        RecorderState.update { it.copy(status = Status.IDLE, error = message) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ pause / stop

    private fun togglePause() = setPaused(RecorderState.state.value.status == Status.RECORDING)

    private fun setPaused(pause: Boolean) {
        val e = engine ?: return
        if (pause) e.pause() else e.resume()
        RecorderState.update { it.copy(status = if (pause) Status.PAUSED else Status.RECORDING) }
        overlay?.setPaused(pause)
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(pause, e.elapsedMs()))
    }

    private fun stopRecording() {
        val e = engine
        engine = null
        ticker?.cancel()
        overlay?.hide(); overlay = null
        if (e == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        Thread {
            e.stop()
            main.post {
                RecorderState.update { it.copy(status = Status.IDLE) }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                toast("تم حفظ التسجيل في Movies/ScreenRecorder")
            }
        }.start()
    }

    // ------------------------------------------------------------------ engine callbacks

    override fun onError(message: String) {
        main.post {
            RecorderState.update { it.copy(error = message) }
            stopRecording()
        }
    }

    override fun onWarning(message: String) { main.post { toast(message) } }

    override fun onProjectionStopped() { main.post { stopRecording() } }

    // ------------------------------------------------------------------ helpers

    private fun freeBytes(): Long =
        runCatching { StatFs(Environment.getExternalStorageDirectory().path).availableBytes }.getOrDefault(Long.MAX_VALUE)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun servicePi(action: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, RecorderService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(paused: Boolean, elapsedMs: Long): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(if (paused) "التسجيل متوقف مؤقتًا" else "جارٍ تسجيل الشاشة")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, if (paused) "استئناف" else "إيقاف مؤقت", servicePi(if (paused) ACTION_RESUME else ACTION_PAUSE, 1))
            .addAction(0, "إنهاء", servicePi(ACTION_STOP, 2))
        if (!paused) b.setShowWhen(true).setUsesChronometer(true).setWhen(System.currentTimeMillis() - elapsedMs)
        return b.build()
    }

    override fun onDestroy() {
        ticker?.cancel()
        overlay?.hide()
        // أمان: إذا دُمّرت الخدمة والمحرّك يعمل، أوقفه وأنهِ الملف
        engine?.let { e -> engine = null; Thread { e.stop() }.start() }
        scope.cancel()
        RecorderState.update { it.copy(status = Status.IDLE) }
        super.onDestroy()
    }
}
