package com.screenrecorder.pro.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** حالة مشتركة بين الخدمة والواجهة. */
object RecorderState {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    fun update(block: (UiState) -> UiState) = _state.update(block)
}
