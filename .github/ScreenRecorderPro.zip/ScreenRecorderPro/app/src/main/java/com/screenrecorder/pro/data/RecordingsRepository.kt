package com.screenrecorder.pro.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

object RecordingsRepository {
    fun list(context: Context): List<RecordingItem> {
        val out = mutableListOf<RecordingItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DURATION,
        )
        runCatching {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection,
                "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?", arrayOf("Movies/ScreenRecorder%"),
                "${MediaStore.Video.Media.DATE_ADDED} DESC",
            )?.use { c ->
                while (c.moveToNext()) {
                    out += RecordingItem(
                        uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0)),
                        name = c.getString(1) ?: "",
                        sizeBytes = c.getLong(2),
                        durationMs = c.getLong(3),
                    )
                }
            }
        }
        return out
    }

    fun delete(context: Context, uri: Uri): Boolean =
        try { context.contentResolver.delete(uri, null, null) > 0 } catch (e: SecurityException) { false }
}
