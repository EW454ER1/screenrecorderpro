package com.screenrecorder.pro.recorder

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import com.screenrecorder.pro.data.RecordingSettings
import com.screenrecorder.pro.util.VideoSizing
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.max
import kotlin.math.min

/**
 * محرّك التسجيل: VirtualDisplay -> MediaCodec (Surface، تسريع عتادي إن وُجد) -> MediaMuxer -> MediaStore.
 * الصوت: AudioPlaybackCapture (داخلي) و/أو الميكروفون -> AAC.
 * لا نسخ للإطارات: الإطارات تذهب مباشرة من النظام إلى المشفّر عبر Surface.
 */
class ScreenRecorderEngine(
    private val context: Context,
    private val projection: MediaProjection,
    private val settings: RecordingSettings,
    private val listener: Listener,
) {
    interface Listener {
        fun onError(message: String)
        fun onWarning(message: String)
        fun onProjectionStopped()
    }

    private companion object {
        const val VIDEO_MIME = MediaFormat.MIMETYPE_VIDEO_AVC
        const val SAMPLE_RATE = 44_100
        const val AUDIO_CHUNK = 1024
    }

    private var uri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var muxer: MediaMuxer? = null
    private var videoEncoder: MediaCodec? = null
    private var audioEncoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var internalRecord: AudioRecord? = null
    private var micRecord: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val muxLock = ReentrantLock()
    private val muxCond = muxLock.newCondition()
    private var muxerStarted = false
    private var aborted = false
    private var tracksAdded = 0
    private var tracksExpected = 1
    private var videoTrack = -1
    private var audioTrack = -1

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var pausedTotalUs = 0L
    @Volatile private var pauseStartUs = 0L
    private var startUs = 0L
    private var lastVideoPts = 0L
    private var lastAudioPts = 0L
    private val written = AtomicLong(0)
    private val stopped = AtomicBoolean(false)
    private val failed = AtomicBoolean(false)

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() = listener.onProjectionStopped()
    }

    fun bytesWritten(): Long = written.get()

    fun elapsedMs(): Long {
        if (!running) return 0
        val now = nowUs()
        val extra = if (paused) now - pauseStartUs else 0
        return max(0L, (now - startUs - pausedTotalUs - extra) / 1000)
    }

    private fun nowUs() = System.nanoTime() / 1000

    // ------------------------------------------------------------------ start

    fun start() {
        try {
            startInternal()
        } catch (t: Throwable) {
            failed.set(true)
            stop()
            throw t
        }
    }

    private fun startInternal() {
        val metrics = DisplayMetrics()
        val dm = context.getSystemService(DisplayManager::class.java)
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metrics)

        val codecInfo = pickEncoder() ?: throw IllegalStateException("لا يوجد مشفّر H.264 على هذا الجهاز")
        val vc = codecInfo.getCapabilitiesForType(VIDEO_MIME).videoCapabilities

        var w = 0
        var h = 0
        for (target in listOf(settings.height, 720, 540, 480).distinct().filter { it <= settings.height }) {
            val (cw, ch) = VideoSizing.computeSize(metrics.widthPixels, metrics.heightPixels, target)
            if (vc.isSizeSupported(cw, ch)) { w = cw; h = ch; break }
        }
        if (w == 0) throw IllegalStateException("دقة الشاشة غير مدعومة من المشفّر")

        val maxFps = runCatching { vc.getSupportedFrameRatesFor(w, h).upper.toInt() }.getOrDefault(30)
        val fps = min(settings.fps, maxFps)
        if (fps < settings.fps) listener.onWarning("الجهاز لا يدعم ${settings.fps} إطارًا/ث؛ تم استخدام $fps")
        val bitrate = min(settings.bitrateMbps.toLong() * 1_000_000L, vc.bitrateRange.upper.toLong()).toInt()

        // ----- الصوت
        if (settings.internalAudio) internalRecord = buildInternalRecord()
        if (settings.mic) micRecord = buildMicRecord()
        val hasAudio = internalRecord != null || micRecord != null
        tracksExpected = if (hasAudio) 2 else 1

        // ----- الملف
        val name = "Rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenRecorder")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("تعذّر إنشاء ملف في Movies/ScreenRecorder")
        pfd = resolver.openFileDescriptor(uri!!, "rw")
            ?: throw IllegalStateException("تعذّر فتح الملف للكتابة")
        muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // ----- مشفّر الفيديو
        val vFormat = MediaFormat.createVideoFormat(VIDEO_MIME, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 200_000L)
        }
        val venc = MediaCodec.createByCodecName(codecInfo.name)
        videoEncoder = venc
        venc.configure(vFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = venc.createInputSurface()
        venc.start()

        // ----- مشفّر الصوت
        if (hasAudio) {
            val aFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192)
            }
            val aenc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            audioEncoder = aenc
            aenc.configure(aFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            aenc.start()
        }

        // ----- العرض الافتراضي (التسجيل يبدأ هنا)
        projection.registerCallback(callback, Handler(Looper.getMainLooper()))
        startUs = nowUs()
        running = true
        videoThread = Thread({ videoLoop() }, "rec-video").also { it.start() }
        if (hasAudio) audioThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
        virtualDisplay = projection.createVirtualDisplay(
            "ScreenRecorderPro", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, inputSurface, null, null,
        )
    }

    private fun pickEncoder(): MediaCodecInfo? =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(VIDEO_MIME, true) } }
            .sortedByDescending { it.isHardwareAccelerated }
            .firstOrNull()

    @SuppressLint("MissingPermission")
    private fun buildInternalRecord(): AudioRecord? = try {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        AudioRecord.Builder()
            .setAudioPlaybackCaptureConfig(cfg)
            .setAudioFormat(monoFormat())
            .setBufferSizeInBytes(audioBufferBytes())
            .build()
            .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
            ?: run { listener.onWarning("تعذّر تفعيل الصوت الداخلي على هذا الجهاز"); null }
    } catch (e: Exception) {
        listener.onWarning("الصوت الداخلي غير متاح: ${e.message}")
        null
    }

    @SuppressLint("MissingPermission")
    private fun buildMicRecord(): AudioRecord? = try {
        AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.MIC)
            .setAudioFormat(monoFormat())
            .setBufferSizeInBytes(audioBufferBytes())
            .build()
            .takeIf { it.state == AudioRecord.STATE_INITIALIZED }
            ?: run { listener.onWarning("تعذّر تشغيل الميكروفون"); null }
    } catch (e: Exception) {
        listener.onWarning("الميكروفون غير متاح: ${e.message}")
        null
    }

    private fun monoFormat() = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(SAMPLE_RATE)
        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
        .build()

    private fun audioBufferBytes(): Int = max(
        AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) * 2,
        AUDIO_CHUNK * 2 * 4,
    )

    // ------------------------------------------------------------------ pause / resume

    fun pause() {
        if (!running || paused) return
        pauseStartUs = nowUs()
        paused = true
        setSuspend(1)
    }

    fun resume() {
        if (!running || !paused) return
        pausedTotalUs += nowUs() - pauseStartUs
        paused = false
        setSuspend(0)
        runCatching {
            videoEncoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        }
    }

    private fun setSuspend(v: Int) = runCatching {
        videoEncoder?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_SUSPEND, v) })
    }

    // ------------------------------------------------------------------ threads

    private fun videoLoop() {
        val enc = videoEncoder ?: return
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, 10_000)
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    videoTrack = addTrack(enc.outputFormat)
                } else if (idx >= 0) {
                    val buf = enc.getOutputBuffer(idx)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (buf != null && info.size > 0) {
                        val pts = max(info.presentationTimeUs - startUs - pausedTotalUs, lastVideoPts)
                        lastVideoPts = pts
                        info.presentationTimeUs = pts
                        writeSample(videoTrack, buf, info)
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
                if (!running && stopped.get() && idx == MediaCodec.INFO_TRY_AGAIN_LATER && aborted) break
            }
        } catch (e: Exception) {
            fail("خطأ في تشفير الفيديو: ${e.message}")
        }
    }

    private fun audioLoop() {
        val enc = audioEncoder ?: return
        val a = ShortArray(AUDIO_CHUNK)
        val b = ShortArray(AUDIO_CHUNK)
        val mixed = ShortArray(AUDIO_CHUNK)
        try {
            internalRecord?.startRecording()
            micRecord?.startRecording()
            while (running) {
                val gotA = internalRecord?.let { readFull(it, a) } ?: false
                val gotB = micRecord?.let { readFull(it, b) } ?: false
                drainAudio(false)
                if (paused || (!gotA && !gotB)) continue
                for (i in 0 until AUDIO_CHUNK) {
                    val s = (if (gotA) a[i].toInt() else 0) + (if (gotB) b[i].toInt() else 0)
                    mixed[i] = s.coerceIn(-32768, 32767).toShort()
                }
                val raw = nowUs() - AUDIO_CHUNK * 1_000_000L / SAMPLE_RATE
                val pts = max(raw - startUs - pausedTotalUs, lastAudioPts)
                lastAudioPts = pts
                val idx = enc.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    val ib = enc.getInputBuffer(idx)!!
                    ib.clear()
                    ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(mixed)
                    enc.queueInputBuffer(idx, 0, AUDIO_CHUNK * 2, pts, 0)
                }
            }
            val idx = enc.dequeueInputBuffer(100_000)
            if (idx >= 0) enc.queueInputBuffer(idx, 0, 0, lastAudioPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drainAudio(true)
        } catch (e: Exception) {
            fail("خطأ في تشفير الصوت: ${e.message}")
        }
    }

    private fun readFull(r: AudioRecord, out: ShortArray): Boolean {
        var off = 0
        while (off < out.size && running) {
            val n = r.read(out, off, out.size - off)
            if (n < 0) return false
            off += n
        }
        return off == out.size
    }

    private fun drainAudio(untilEos: Boolean) {
        val enc = audioEncoder ?: return
        val info = MediaCodec.BufferInfo()
        var tries = 0
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, if (untilEos) 10_000 else 0)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!untilEos || ++tries > 300) return
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> audioTrack = addTrack(enc.outputFormat)
                idx >= 0 -> {
                    val buf = enc.getOutputBuffer(idx)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (buf != null && info.size > 0) writeSample(audioTrack, buf, info)
                    enc.releaseOutputBuffer(idx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    // ------------------------------------------------------------------ muxer

    private fun addTrack(format: MediaFormat): Int = muxLock.withLock {
        val t = muxer!!.addTrack(format)
        tracksAdded++
        if (tracksAdded == tracksExpected) {
            muxer!!.start()
            muxerStarted = true
            muxCond.signalAll()
        }
        t
    }

    private fun writeSample(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        muxLock.withLock {
            var waited = 0
            while (!muxerStarted && !aborted && waited < 3000) {
                muxCond.await(50, TimeUnit.MILLISECONDS); waited += 50
            }
            if (!muxerStarted || track < 0) return
            muxer!!.writeSampleData(track, buf, info)
        }
        written.addAndGet(info.size.toLong())
    }

    // ------------------------------------------------------------------ stop

    private fun fail(message: String) {
        if (stopped.get()) return
        if (failed.compareAndSet(false, true)) listener.onError(message)
    }

    /** آمن للاستدعاء أكثر من مرة وللاستدعاء من أي خيط (غير الرئيسي يُفضَّل). */
    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        if (paused) setSuspend(0)
        runCatching { projection.unregisterCallback(callback) }
        runCatching { virtualDisplay?.release() }
        running = false
        runCatching { videoEncoder?.signalEndOfInputStream() }
        runCatching { audioThread?.join(4000) }
        runCatching { videoThread?.join(4000) }
        muxLock.withLock { aborted = true; muxCond.signalAll() }

        runCatching { projection.stop() }
        runCatching { videoEncoder?.stop() }
        runCatching { videoEncoder?.release() }
        runCatching { inputSurface?.release() }
        runCatching { audioEncoder?.stop() }
        runCatching { audioEncoder?.release() }
        runCatching { internalRecord?.stop() }
        runCatching { internalRecord?.release() }
        runCatching { micRecord?.stop() }
        runCatching { micRecord?.release() }

        var finalized = false
        if (muxerStarted) finalized = runCatching { muxer?.stop() }.isSuccess
        runCatching { muxer?.release() }
        runCatching { pfd?.close() }

        val u = uri
        if (u != null) {
            val resolver = context.contentResolver
            if (finalized && written.get() > 0 && !failed.get()) {
                runCatching {
                    resolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                }
            } else if (finalized && written.get() > 0) {
                // فشل جزئي لكن الملف صالح: احتفظ به
                runCatching {
                    resolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                }
            } else {
                runCatching { resolver.delete(u, null, null) }
            }
        }
    }
}
