package com.screenrecorder.pro.data

data class RecordingSettings(
    val height: Int = 720,
    val fps: Int = 30,
    val bitrateMbps: Int = 4,
    val mic: Boolean = false,
    val internalAudio: Boolean = true,
    val economy: Boolean = false,
    val floating: Boolean = true,
) {
    /** الإعدادات الفعلية؛ الوضع الاقتصادي يخفّض الدقة ومعدل الإطارات والبت. */
    fun effective(): RecordingSettings =
        if (economy) copy(height = 720, fps = minOf(fps, 30), bitrateMbps = minOf(bitrateMbps, 2)) else this
}

enum class Status { IDLE, RECORDING, PAUSED }

data class UiState(
    val status: Status = Status.IDLE,
    val elapsedMs: Long = 0,
    val sizeBytes: Long = 0,
    val error: String? = null,
)

data class RecordingItem(
    val uri: android.net.Uri,
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
)
