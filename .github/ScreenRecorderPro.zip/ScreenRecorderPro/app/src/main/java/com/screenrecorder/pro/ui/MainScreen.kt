package com.screenrecorder.pro.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.screenrecorder.pro.data.RecordingItem
import com.screenrecorder.pro.data.RecordingSettings
import com.screenrecorder.pro.data.Status
import com.screenrecorder.pro.data.UiState
import com.screenrecorder.pro.util.Formatters

class MainActions(
    val onSettings: (RecordingSettings) -> Unit,
    val onStart: () -> Unit,
    val onPause: () -> Unit,
    val onResume: () -> Unit,
    val onStop: () -> Unit,
    val onShare: (RecordingItem) -> Unit,
    val onDelete: (RecordingItem) -> Unit,
    val onDismissError: () -> Unit,
)

@Composable
fun MainScreen(ui: UiState, s: RecordingSettings, recordings: List<RecordingItem>, a: MainActions) {
    val idle = ui.status == Status.IDLE
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("مسجّل الشاشة", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

            // ----- الحالة
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val (label, color) = when (ui.status) {
                        Status.IDLE -> "جاهز" to Color.Gray
                        Status.RECORDING -> "جارٍ التسجيل" to Color(0xFFE53935)
                        Status.PAUSED -> "متوقف مؤقتًا" to Color(0xFFFFA000)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.size(12.dp).background(color, CircleShape))
                        Text(label)
                    }
                    Text(Formatters.duration(ui.elapsedMs), fontSize = 52.sp, fontWeight = FontWeight.Light)
                    Text("حجم الملف: ${Formatters.size(ui.sizeBytes)}", style = MaterialTheme.typography.bodyMedium)
                }
            }

            ui.error?.let {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(it, Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer)
                        TextButton(onClick = a.onDismissError) { Text("إغلاق") }
                    }
                }
            }

            // ----- التحكم
            if (idle) {
                Button(onClick = a.onStart, modifier = Modifier.fillMaxWidth()) { Text("● ابدأ التسجيل") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = if (ui.status == Status.PAUSED) a.onResume else a.onPause,
                        modifier = Modifier.weight(1f),
                    ) { Text(if (ui.status == Status.PAUSED) "▶ استئناف" else "⏸ إيقاف مؤقت") }
                    Button(
                        onClick = a.onStop, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    ) { Text("⏹ إنهاء") }
                }
            }

            // ----- الإعدادات
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الإعدادات", fontWeight = FontWeight.Bold)
                    Text("الدقة")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(720, 1080).forEach { h ->
                            FilterChip(s.height == h, { a.onSettings(s.copy(height = h)) }, { Text("${h}p") }, enabled = idle && !s.economy)
                        }
                    }
                    Text("معدل الإطارات")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(24, 30, 60).forEach { f ->
                            FilterChip(s.fps == f, { a.onSettings(s.copy(fps = f)) }, { Text("$f FPS") }, enabled = idle)
                        }
                    }
                    Text("معدل البت: ${s.bitrateMbps} Mbps")
                    Slider(
                        value = s.bitrateMbps.toFloat(), onValueChange = { a.onSettings(s.copy(bitrateMbps = it.toInt())) },
                        valueRange = 1f..16f, steps = 14, enabled = idle && !s.economy,
                    )
                    SwitchRow("الصوت الداخلي", s.internalAudio, idle) { a.onSettings(s.copy(internalAudio = it)) }
                    SwitchRow("الميكروفون", s.mic, idle) { a.onSettings(s.copy(mic = it)) }
                    SwitchRow("وضع اقتصادي (للأجهزة الضعيفة)", s.economy, idle) { a.onSettings(s.copy(economy = it)) }
                    SwitchRow("الزر العائم", s.floating, idle) { a.onSettings(s.copy(floating = it)) }
                    Text(
                        "التطبيقات التي تمنع تصوير الشاشة (FLAG_SECURE) تظهر سوداء في التسجيل؛ لا يتجاوز التطبيق هذه الحماية.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            // ----- التسجيلات
            Text("التسجيلات (Movies/ScreenRecorder)", fontWeight = FontWeight.Bold)
            if (recordings.isEmpty()) Text("لا توجد تسجيلات بعد", style = MaterialTheme.typography.bodyMedium)
            recordings.take(30).forEach { r ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, style = MaterialTheme.typography.bodyLarge)
                            Text("${Formatters.duration(r.durationMs)} • ${Formatters.size(r.sizeBytes)}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton({ a.onShare(r) }) { Icon(Icons.Default.Share, "مشاركة") }
                        IconButton({ a.onDelete(r) }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked, onChange, enabled = enabled)
    }
}
