package com.screenrecorder.pro.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val Light = lightColorScheme(primary = Color(0xFFD32F2F), secondary = Color(0xFF455A64))
private val Dark = darkColorScheme(primary = Color(0xFFFF6B63), secondary = Color(0xFF90A4AE))

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    // واجهة عربية: اتجاه RTL دائمًا
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
    }
}
