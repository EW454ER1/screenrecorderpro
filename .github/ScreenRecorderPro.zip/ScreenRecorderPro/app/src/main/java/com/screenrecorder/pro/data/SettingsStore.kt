package com.screenrecorder.pro.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): RecordingSettings {
        val d = RecordingSettings()
        return RecordingSettings(
            height = prefs.getInt("height", d.height),
            fps = prefs.getInt("fps", d.fps),
            bitrateMbps = prefs.getInt("bitrate", d.bitrateMbps),
            mic = prefs.getBoolean("mic", d.mic),
            internalAudio = prefs.getBoolean("internal", d.internalAudio),
            economy = prefs.getBoolean("economy", d.economy),
            floating = prefs.getBoolean("floating", d.floating),
        )
    }

    fun save(s: RecordingSettings) {
        prefs.edit()
            .putInt("height", s.height).putInt("fps", s.fps).putInt("bitrate", s.bitrateMbps)
            .putBoolean("mic", s.mic).putBoolean("internal", s.internalAudio)
            .putBoolean("economy", s.economy).putBoolean("floating", s.floating)
            .apply()
    }
}
