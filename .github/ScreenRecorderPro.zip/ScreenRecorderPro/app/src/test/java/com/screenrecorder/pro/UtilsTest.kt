package com.screenrecorder.pro

import com.screenrecorder.pro.data.RecordingSettings
import com.screenrecorder.pro.util.Formatters
import com.screenrecorder.pro.util.VideoSizing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UtilsTest {
    @Test fun durationFormats() {
        assertEquals("00:00", Formatters.duration(0))
        assertEquals("01:05", Formatters.duration(65_000))
        assertEquals("1:01:01", Formatters.duration(3_661_000))
        assertEquals("00:00", Formatters.duration(-5))
    }

    @Test fun sizeFormats() {
        assertEquals("512 B", Formatters.size(512))
        assertEquals("1.0 MB", Formatters.size(1_048_576))
    }

    @Test fun portraitSize() {
        assertEquals(720 to 1600, VideoSizing.computeSize(1080, 2400, 720))
    }

    @Test fun landscapeSize() {
        assertEquals(1600 to 720, VideoSizing.computeSize(2400, 1080, 720))
    }

    @Test fun smallScreenNotUpscaled() {
        assertEquals(480 to 800, VideoSizing.computeSize(480, 800, 720))
    }

    @Test fun sizesAreEven() {
        val (w, h) = VideoSizing.computeSize(1080, 2339, 720)
        assertTrue(w % 2 == 0 && h % 2 == 0)
    }

    @Test fun economyMode() {
        val e = RecordingSettings(height = 1080, fps = 60, bitrateMbps = 12, economy = true).effective()
        assertEquals(720, e.height); assertEquals(30, e.fps); assertEquals(2, e.bitrateMbps)
    }
}
