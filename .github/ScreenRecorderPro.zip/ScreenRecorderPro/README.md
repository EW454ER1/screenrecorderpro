# Android Screen Recorder Pro

مسجّل شاشة بـ Kotlin + Jetpack Compose (واجهة عربية RTL).
MediaProjection → VirtualDisplay → MediaCodec (H.264، عتادي إن وُجد) → MediaMuxer → `Movies/ScreenRecorder` عبر MediaStore.

## المتطلبات
- Android Studio (Koala أو أحدث) أو: JDK 17 + Android SDK (platform 34, build-tools)
- جهاز/محاكي Android 10 (API 29) أو أحدث

## البناء
> ملف `gradle-wrapper.jar` غير مرفق. افتح المشروع في Android Studio (يولّده تلقائيًا)،
> أو نفّذ مرة واحدة في جذر المشروع: `gradle wrapper --gradle-version 8.7`

```bash
./gradlew testDebugUnitTest   # الاختبارات
./gradlew assembleDebug       # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease     # app/build/outputs/apk/release/app-release.apk (موقّع بمفتاح debug للتجربة)
```

## التثبيت
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
أو انسخ الملف للهاتف وافتحه (فعّل «التثبيت من مصادر غير معروفة»).

## ملاحظات
- يطلب النظام موافقتك قبل **كل** جلسة تسجيل، ويعرض مؤشره الخاص.
- لا يوجد أي رفع للشبكة؛ لا يوجد إذن INTERNET.
- التطبيقات المحمية بـ FLAG_SECURE تظهر سوداء؛ لا يحاول التطبيق تجاوزها.
- الزر العائم يحتاج إذن «الظهور فوق التطبيقات»، ويظهر ضمن الفيديو إن كان على الشاشة (اسحبه أو عطّله). الإشعار فيه أزرار الإيقاف المؤقت/الإنهاء دائمًا.
- الصوت الداخلي يعتمد على التطبيق المصدر (بعض التطبيقات تمنع التقاطه) وعلى الجهاز.
- تغيّر اتجاه الشاشة: أبعاد الفيديو ثابتة طوال الجلسة، ويقوم النظام بتحجيم المحتوى.
- الأجهزة الضعيفة (2–4GB): فعّل «الوضع الاقتصادي» (720p، ≤30fps، ≤2Mbps).
